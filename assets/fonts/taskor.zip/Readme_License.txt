By downloading or using this font, you agree to the terms outlined in our Product Usage Agreement.

🔹 Personal Use Only
This font is free and comes in its full version, but it is for personal use only. You can start using it by making a donation to support our creativity. Commercial use is strictly prohibited.

🔹 Want the Full Version?
Get access to the complete set of glyphs and a commercial license here:
👉 https://salamahtype.com/taskor

Note: Only the full version includes all glyphs and extra features.

🔹 Support Us
If you’d like to support the creator, donations are appreciated!
👉 https://paypal.me/aswangga

🔹 Need Help or Have Questions?
Feel free to contact us:
📧 salamahtype@gmail.com